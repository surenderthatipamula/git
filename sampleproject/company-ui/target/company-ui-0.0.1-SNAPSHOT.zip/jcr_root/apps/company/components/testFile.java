opps, now we have some text in here (file system side)

2nd change - should add to JCR after Maven build.